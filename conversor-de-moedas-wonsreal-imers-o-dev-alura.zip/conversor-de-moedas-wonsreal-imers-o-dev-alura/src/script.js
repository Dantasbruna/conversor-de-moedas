
function conversor(){ 
//Criação das variáveis e entrada de dados
let valorWons = prompt("Digite o valor em Wons: ")
let cotacaoReal = prompt("Digite o valor da cotação de wons em reais")

//Conversão de Wons para Reais
let resultado = valorWons * cotacaoReal

//Exibição da primeira conversão
alert(resultado)
}