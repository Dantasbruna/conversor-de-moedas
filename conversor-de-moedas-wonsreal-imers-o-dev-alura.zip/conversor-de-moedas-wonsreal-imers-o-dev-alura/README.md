# Conversor de moedas ( wons - real) Imersão Dev Alura 

A Pen created on CodePen.

Original URL: [https://codepen.io/Bruna-Dantas/pen/pvoQxgX](https://codepen.io/Bruna-Dantas/pen/pvoQxgX).

Estou participando da Imersão Dev-Alura 9ª edição, no qual na primeira aula aprendemos como fazer um conversor de moedas utilizando o Javascript. Após o fim da aula tivemos um desafio onde poderiámos modificar certas coisas, pois então no meu eu modifiquei a imagem de fundo, imagem de fundo do footer, e pus outra fonte na logo "Imersão Dev-Alura. 
Esse conversor é em wons então nada mais coreano do que algo que seja referente ao país, onde coloquei uma foto do grupo de kpop Exo no qual eu gosto muito! 